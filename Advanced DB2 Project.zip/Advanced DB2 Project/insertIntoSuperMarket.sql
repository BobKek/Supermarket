


#insert into Branch values (1 , 'Lebanon' , 'Beirut' ) , (2,'Lebanon','Saida') , (3,'Lebanon','Tripoli') ;


use SuperMarket;
insert into Employee (employeeid , first_name , last_name , phone , salary ,task , branchid)
					values (1,'Ali','Rahal','03727679',2000, 'KING' , 1),
                    (2,'Bob','Owaidat' , '70093260' , 500, 'HR' , 2 ),
                    (3,'Hassan' , 'Badran' , '12345678' , 1200 , 'Full' , 3 );
                    
                    insert into Employee (employeeid , first_name , last_name , phone , salary ,task , branchid) 
                    values(4,'Noor' , 'Shoukier' , '71528142' , 2100 , 'Developer' , 1 );
                    
select * from Branch;

use SuperMarket;
INSERT INTO Employee (first_name , last_name, phone, salary , employment_date, task,branchid) VALUES ('sds' ,'dgsdg' ,'dgsd' ,234234 , CURDATE(),'kinging' , 10);