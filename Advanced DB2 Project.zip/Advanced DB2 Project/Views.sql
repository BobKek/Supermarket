#Views

CREATE VIEW EmployeeView AS
    select employeeid, e.name name, phone, birthday, salary, employment_date,country, city, p.name positionname, b.branchid branchid, p.positionid positionid from Employee e join Branch b join Position p
where e.positionid=p.positionid and e.branchid = b.branchid;


Create View ProductView as
select p.productid, p.name, price, c.name category_name, description, c.categoryid from product p join category c where p.categoryid = c.categoryid;

create View RewardView as 
select p.productid, name, points, price from Reward r join Product p where r.productid = p.productid;



#### Custom View for better experience
		
        ####Branch Transfer View
		create view branch_transfers as
			select id, name, old_branch_name `Old Branch`, new_branch_name `New Branch` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_branch_name != new_branch_name;
            
		####Position Change View
        create view position_changes as
			select id, name, old_position_name `Old Position`, new_position_name `New Position` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_position_name != new_position_name;
            
		####Salary Change View
        create view salary_changes as
			select id, name, old_salary `Old Salary`, new_salary `New Salary` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_salary != new_salary;
            
