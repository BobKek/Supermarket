use SuperMarket;
alter table Employee
drop foreign key employee_ibfk_1;

alter table Employee
drop foreign key employee_ibfk_2;

alter table Product
drop foreign key product_ibfk_1;

alter table SuperMarket.Order
drop foreign key order_ibfk_1;

alter table SuperMarket.Order
drop foreign key order_ibfk_2;

alter table OrderDetails
drop foreign key orderdetails_ibfk_1;

alter table OrderDetails
drop foreign key orderdetails_ibfk_2;

alter table Stock
drop foreign key stock_ibfk_1;

alter table Manager
drop foreign key manager_ibfk_1;

alter table SupplyDetails
drop foreign key supplydetails_ibfk_1;

alter table SupplyDetails
drop foreign key supplydetails_ibfk_2;

alter table Reward
drop foreign key reward_ibfk_1;

