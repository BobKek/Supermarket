


use SuperMarket;

insert into Branch (country , city) values ('Lebanon' , 'Beirut' ) , ('Lebanon','Saida') , ('Lebanon','Tripoli') ;


insert into Employee (name, phone , salary ,positionid , branchid, birthday)
					values ('Ali Rahal','03727679',2000, 1 , 1, '1998-09-05'),
                    ('Bob2 Owaidat' , '70093260' , 500, 2 , 2, '1998-12-8' ),
                    ('Hassan Badran' , '12345678' , 1200 , 3 , 3,'1997-12-12' );
                    
insert into Position (name) values ('Cashier'), ('Sales Assistant'), ('IT Guy'), ('Delivery');

insert into Category  (categoryid , name) values (1,'Electronics') , (2,'Kitchen') , (3,'Furniture'), (4, 'Grocery');              



insert into product (name , price , description, categoryid) values ('test' , 123, '123123123123', 3);

insert into Manager (name, username, password, branchid)
values ('Bob', 'bob', 'bob', 1);

insert into Customer (name, username, password, phone, email, points)
values ('Safaa Diab', 'safaa', 'safaa', 70123909, null, 100);

