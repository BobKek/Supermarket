-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema SuperMarket
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema SuperMarket
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `SuperMarket` DEFAULT CHARACTER SET utf8 ;
USE `SuperMarket` ;

-- -----------------------------------------------------
-- Table `SuperMarket`.`Branch`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Branch` (
  `branchid` INT NOT NULL auto_increment,
  `country` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`branchid`))
auto_increment = 1;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Customer` (
  `customerid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `username` VARCHAR(40) NOT NULL,
  `password` VARCHAR(40) NULL,
  `phone` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NULL,
  `points` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`customerid`)
 )auto_increment = 1000;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Category` (
  `categoryid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(40) NOT NULL,
  PRIMARY KEY (`categoryid`))
auto_increment = 1;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Product` (
  `productid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `price` VARCHAR(45) NOT NULL,
  `description` VARCHAR(100) NULL DEFAULT 'No description Available',
  `categoryid` INT NOT NULL,
  PRIMARY KEY (`productid`),
  CONSTRAINT `categoryid_product`
    FOREIGN KEY (`categoryid`)
    REFERENCES `SuperMarket`.`Category` (`categoryid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
auto_increment = 1000;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Employee` (
  `employeeid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  `birthday` Date NOT NULL,
  `salary` INT NOT NULL,
  `employment_date` DATE,
  `branchid` INT NOT NULL,
  `positionid` int not null,
  PRIMARY KEY (`employeeid`),
  CONSTRAINT `positionid_employee` foreign key (`positionid`) references `SuperMarket`.`Position`(positionid),
  CONSTRAINT `branchid_employee`
    FOREIGN KEY (`branchid`)
    REFERENCES `SuperMarket`.`Branch` (`branchid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
auto_increment = 1000;




-- -----------------------------------------------------
-- Table `SuperMarket`.`Order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Order` (
  `orderid` INT NOT NULL AUTO_INCREMENT,
  `date` DATETIME NOT NULL,
  `employeeid` INT NOT NULL,
  `customerid` INT NOT NULL,
  PRIMARY KEY (`orderid`),
  CONSTRAINT `employeeid_order`
    FOREIGN KEY (`employeeid`)
    REFERENCES `SuperMarket`.`Employee` (`employeeid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `customerid_order`
    FOREIGN KEY (`customerid`)
    REFERENCES `SuperMarket`.`Customer` (`customerid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
auto_increment = 100000;



-- -----------------------------------------------------
-- Table `SuperMarket`.`OrderDetails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`OrderDetails` (
  `orderid` INT NOT NULL,
  `productid` INT NOT NULL,
  `quantity` INT NOT NULL,
  
  CONSTRAINT `orderid_orderdetails`
    FOREIGN KEY (`orderid`)
    REFERENCES `SuperMarket`.`Order` (`orderid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `productid_orderdetails`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (orderid, productid)
)
ENGINE = InnoDB;



-- -----------------------------------------------------
-- Table `SuperMarket`.`Stock`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Stock` (
  `productid` INT NOT NULL,
  `quantity` INT NOT NULL,
  CONSTRAINT `productid_stock`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (productid)
)
ENGINE = InnoDB;



-- -----------------------------------------------------
-- Table `SuperMarket`.`Supplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Supplier` (
  `supplierid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`supplierid`)
  ) auto_increment = 1;



-- -----------------------------------------------------
-- Table `SuperMarket`.`Manager`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Manager` (
  `managerid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `username` varchar(45) not null,
  `password` varchar(45) not null,
  `branchid` INT NOT NULL,
  PRIMARY KEY (`managerid`),
  CONSTRAINT `branchid_manager`
    FOREIGN KEY (`branchid`)
    REFERENCES `SuperMarket`.`Branch` (`branchid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
auto_increment = 100;



-- -----------------------------------------------------
-- Table `SuperMarket`.`SupplyDetails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`SupplyDetails` (
  `supplydetailsid` INT NOT NULL AUTO_INCREMENT,
  `date` DATETIME NULL,
  `quantity` INT NOT NULL,
  `supplierid` INT NOT NULL,
  `productid` INT NOT NULL,
  PRIMARY KEY (`supplydetailsid`),
  CONSTRAINT `supplierid_supplydetails`
    FOREIGN KEY (`supplierid`)
    REFERENCES `SuperMarket`.`Supplier` (`supplierid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `productid_supplydetails`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;



-- -----------------------------------------------------
-- Table `SuperMarket`.`Reward`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Reward` (
  `productid` INT NOT NULL,
  `points` INT NOT NULL,
  CONSTRAINT `productid_reward`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (productid)
)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- New Additions
-- -----------------------------------------------------

CREATE TABLE IF not exists Position (
							positionid INT NOT NULL auto_increment ,
							name varchar(45) NOT NULL,
                            PRIMARY KEY (positionid)
                            )auto_increment=1;
                            




SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
