
ALTER TABLE Employee ADD birthday Date NOT NULL;               
                    
ALTER TABLE Employee MODIFY employment_date Date;


alter table Employee drop column task;

alter table Employee ADD positionid int;
alter table Employee ADD CONSTRAINT `positionid_employee` foreign key (`positionid`) references `SuperMarket`.`Position`(positionid);


INSERT INTO Product (name,price,description,categoryid) VALUES ( 'tuna', 1, '3elbe tanak', 2) , ('chips' , 2 , 'kis batata' , 2);

