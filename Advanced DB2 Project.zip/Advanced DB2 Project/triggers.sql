
############################################################
CREATE TABLE product_tracking(
    id INT AUTO_INCREMENT PRIMARY KEY,
    productid int not null,
    name varchar(45) NOT NULL,
    old_price int default 0,
    new_price int default 0,
    modified VARCHAR(50) DEFAULT NULL
);

DELIMITER $$
CREATE TRIGGER before_product_update 
    BEFORE UPDATE ON product
    FOR EACH ROW 
BEGIN
	declare s varchar(255);
    if (OLD.price > NEW.price) then
			SET s = 'Price Discount';
		else
			SET s = 'Price Increased';
		end if;
	if (OLD.price != NEW.price) then
		INSERT INTO product_tracking
		SET productid = OLD.productid,
		name = OLD.name,
		old_price = OLD.price,
        new_price = NEW.price,
        modified = s;
	end if;
END$$
DELIMITER ;


#### For testing
		insert into product (productid, name , price , description, categoryid) values (1009,'test' , 123, '123123123123', 3);

        update product set price = 200 where productid=1009;
        update product set price = 20 where productid=1009;
        update product set price = 200 where productid=1009;
        update product set price = 20 where productid=1009;
        update product set price = 2 where productid=1009;
        
        #select * from product_tracking; 
#### Testing

#### Dropping
		#drop table product_tracking;
		#delete from product where productid=1009;
        
		#drop trigger before_product_update;
        #drop trigger before_delete_product;
        #drop trigger before_delete_category;
####
        
        delimiter $$
        create trigger before_product_delete
        before delete on product
        for each row
        begin
			delete from reward where productid = OLD.productid;
            insert into product_tracking 
            set modified = 'Product deleted', productid= OLD.productid, name = OLD.name;
        end$$ 
        delimiter ;
        
        
        delimiter $$
        create trigger before_category_delete
        before delete on category
        for each row
        begin
			delete from product where categoryid = OLD.categoryid;
		end$$
		delimiter ;
        
        insert into category (categoryid,name) values (6,'test category');
        insert into product (name, price, categoryid) values ('asd',123,6);
        
        
        ###################################

############################################################



############################################################
CREATE TABLE employee_changes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    employeeid int not null,
    old_salary int,
    new_salary int,
    old_positionid int,
    new_positionid int,
    old_branchid int,
    new_branchid int,
    old_branch_name varchar(100),
    new_branch_name varchar(100),
    old_position_name varchar(50),
    new_position_name varchar(50),
    modified VARCHAR(255) DEFAULT NULL
);


DELIMITER $$
CREATE TRIGGER before_employee_update 
    BEFORE UPDATE ON employee
    FOR EACH ROW 
BEGIN
	declare s varchar(255);
    SET s = '';
    if (OLD.salary < NEW.salary) then
		SET s = concat(s,'Salary Raise ');
	elseif (Old.salary > New.salary) then
		SET s = concat(s, 'Salary Decreased ');
	end if;
    
    if (OLD.positionid != NEW.positionid) then
		SET s = concat(s,'Position Changed ');
	end if;
    
    if (OLD.branchid != NEW.branchid) then
		SET s = concat(s,'Branch Transfer');
	end if;
    
        
	if (OLD.salary != NEW.salary or OLD.branchid) then
		INSERT INTO employee_changes
		SET employeeid = OLD.employeeid,
		old_salary = OLD.salary,
        new_salary = NEW.salary,
        old_branchid = OLD.branchid,
        new_branchid = NEW.branchid,
        old_positionid = OLD.positionid,
        new_positionid = NEW.positionid,
        new_position_name = (select name from position where positionid=NEW.positionid),
        old_position_name = (select name from position where positionid=OLD.positionid),
        new_branch_name = (select concat(city,', ',country) from branch where branchid=NEW.branchid),
        old_branch_name = (select concat(city,', ',country) from branch where branchid=OLD.branchid),
        modified = s;
	end if;
    
END$$
DELIMITER ;

#### For Testing
		update employee set salary = 200 where employeeid=1006;
		update employee set salary = 300, branchid=1 where employeeid=1006;
		update employee set salary = 200, positionid=2 where employeeid=1006;
		update employee set salary = 200, branchid=2, positionid=4 where employeeid=1006;

		#select * from employee_changes;
        
        #select * from branch_transfers;
        #select * from position_changes;
        #select * from salary_changes;
####

#### Dropping
		#drop view branch_transfers;
        #drop view position_changes;
        #drop view salary_changes;
		#drop table employee_changes;
		#drop trigger before_employee_update;

#Trigger (foreign keys/Constraints)
DELIMITER $$
CREATE TRIGGER branch_constraints
  AFTER DELETE ON Branch
  FOR EACH ROW
  BEGIN
    set @br_deleted = OLD.branchid;
    #Deleting the branch's employees
    DELETE FROM Employee
    WHERE branchid = @br_deleted;
    #Deleting the branch's manager
    DELETE FROM Manager
    WHERE branchid = @br_deleted;
  END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER position_constraints
  AFTER DELETE ON Position
  FOR EACH ROW
  BEGIN
    set @pos_deleted = OLD.positionid;
    DELETE FROM Employee
    WHERE positionid = @pos_deleted;
  END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER product_constraints
  AFTER DELETE ON Product
  FOR EACH ROW
  BEGIN
    set @product_deleted = OLD.productid;
    #Deleting the stock that corresponds to the deleted product
    DELETE FROM Stock
    WHERE productid = @product_deleted;
    #Deleting the Reward for this product
    DELETE FROM Reward
    WHERE productid = @product_deleted;
  END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER category_constraints
  AFTER DELETE ON Category
  FOR EACH ROW
  BEGIN
    set @category_deleted = OLD.categoryid;
    #Deleting the products of this category
    DELETE FROM Product
    WHERE categoryid = @category_deleted;
  END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER order_constraints
  AFTER DELETE ON SuperMarket.Order
  FOR EACH ROW
  BEGIN
    set @order_deleted = OLD.orderid;
    #Deleting OrderDetails of this Order
    DELETE FROM OrderDetails
    WHERE orderid = @order_deleted;
  END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER supplier_constraints
  AFTER DELETE ON Supplier
  FOR EACH ROW
  BEGIN
    set @supplier_deleted = OLD.supplierid;
    #Deleting SupplierDetails
    DELETE FROM SupplierDetails
    WHERE supplierid = @supplier_deleted;
  END $$
DELIMITER ;


