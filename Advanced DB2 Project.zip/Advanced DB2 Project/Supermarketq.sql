-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema SuperMarket
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema SuperMarket
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `SuperMarket` DEFAULT CHARACTER SET utf8 ;
USE `SuperMarket` ;

-- -----------------------------------------------------
-- Table `SuperMarket`.`Branch`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Branch` (
  `branchid` INT NOT NULL DEFAULT 1,
  `country` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`branchid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Customer` (
  `customerid` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `username` VARCHAR(20) NOT NULL,
  `password` VARCHAR(35) NULL,
  `phone` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NULL,
  `points` INT NOT NULL DEFAULT 0,
  `branchid` INT NOT NULL,
  PRIMARY KEY (`customerid`),
  CONSTRAINT `branchid_customer`
    FOREIGN KEY (`branchid`)
    REFERENCES `SuperMarket`.`Branch` (`branchid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `bid_idx` ON `SuperMarket`.`Customer` (`branchid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Category` (
  `categoryid` INT NOT NULL DEFAULT 1,
  `name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`categoryid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Product` (
  `productid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `price` VARCHAR(45) NOT NULL,
  `description` VARCHAR(100) NULL DEFAULT 'No description Available',
  `categoryid` INT NOT NULL,
  PRIMARY KEY (`productid`),
  CONSTRAINT `categoryid_product`
    FOREIGN KEY (`categoryid`)
    REFERENCES `SuperMarket`.`Category` (`categoryid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `categoryid_idx` ON `SuperMarket`.`Product` (`categoryid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Employee` (
  `employeeid` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  `salary` INT NOT NULL,
  `employment_date` DATETIME NOT NULL DEFAULT NOW(),
  `task` VARCHAR(10) NOT NULL,
  `branchid` INT NOT NULL,
  PRIMARY KEY (`employeeid`),
  CONSTRAINT `branchid_employee`
    FOREIGN KEY (`branchid`)
    REFERENCES `SuperMarket`.`Branch` (`branchid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `branchid_idx` ON `SuperMarket`.`Employee` (`branchid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Order` (
  `orderid` INT NOT NULL AUTO_INCREMENT,
  `date` DATETIME NOT NULL,
  `employeeid` INT NOT NULL,
  `customerid` INT NOT NULL,
  PRIMARY KEY (`orderid`),
  CONSTRAINT `employeeid_order`
    FOREIGN KEY (`employeeid`)
    REFERENCES `SuperMarket`.`Employee` (`employeeid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `customerid_order`
    FOREIGN KEY (`customerid`)
    REFERENCES `SuperMarket`.`Customer` (`customerid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `employeeid_idx` ON `SuperMarket`.`Order` (`employeeid` ASC) VISIBLE;

CREATE INDEX `customerid_idx` ON `SuperMarket`.`Order` (`customerid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`OrderDetails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`OrderDetails` (
  `orderid` INT NOT NULL,
  `productid` INT NOT NULL,
  `quantity` INT NOT NULL,
  
  CONSTRAINT `orderid_orderdetails`
    FOREIGN KEY (`orderid`)
    REFERENCES `SuperMarket`.`Order` (`orderid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `productid_orderdetails`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (orderid, productid)
)
ENGINE = InnoDB;

CREATE INDEX `orderid_idx` ON `SuperMarket`.`OrderDetails` (`orderid` ASC) VISIBLE;

CREATE INDEX `productid_idx` ON `SuperMarket`.`OrderDetails` (`productid` ASC) VISIBLE;

-- -----------------------------------------------------
-- Table `SuperMarket`.`Stock`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Stock` (
  `productid` INT NOT NULL,
  `quantity` INT NOT NULL,
  CONSTRAINT `productid_stock`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (productid)
)
ENGINE = InnoDB;

CREATE INDEX `productid_idx` ON `SuperMarket`.`Stock` (`productid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Supplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Supplier` (
  `supplierid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  `productid` INT NOT NULL,
  PRIMARY KEY (`supplierid`),
  CONSTRAINT `productid_supplier`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `productid_idx` ON `SuperMarket`.`Supplier` (`productid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Manager`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Manager` (
  `managerid` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `branchid` INT NOT NULL,
  PRIMARY KEY (`managerid`),
  CONSTRAINT `branchid_manager`
    FOREIGN KEY (`branchid`)
    REFERENCES `SuperMarket`.`Branch` (`branchid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `branchid_idx` ON `SuperMarket`.`Manager` (`branchid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`SupplyDetails`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`SupplyDetails` (
  `supply_details_id` INT NOT NULL AUTO_INCREMENT,
  `date` DATETIME NULL,
  `quantity` INT NOT NULL,
  `supplierid` INT NOT NULL,
  `productid` INT NOT NULL,
  PRIMARY KEY (`supply_details_id`),
  CONSTRAINT `supplierid_supplydetails`
    FOREIGN KEY (`supplierid`)
    REFERENCES `SuperMarket`.`Supplier` (`supplierid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `productid_supplydetails`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `supplierid_idx` ON `SuperMarket`.`SupplyDetails` (`supplierid` ASC) VISIBLE;

CREATE INDEX `productid_idx` ON `SuperMarket`.`SupplyDetails` (`productid` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `SuperMarket`.`Reward`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `SuperMarket`.`Reward` (
  `productid` INT NOT NULL,
  `cost` INT NOT NULL,
  CONSTRAINT `productid_reward`
    FOREIGN KEY (`productid`)
    REFERENCES `SuperMarket`.`Product` (`productid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    primary key (productid)
)
ENGINE = InnoDB;

CREATE INDEX `productid_idx` ON `SuperMarket`.`Reward` (`productid` ASC) VISIBLE;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
