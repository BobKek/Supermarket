
############################################################
CREATE TABLE product_tracking(
    id INT AUTO_INCREMENT PRIMARY KEY,
    productid int not null,
    name varchar(45) NOT NULL,
    old_price int default 0,
    new_price int default 0,
    modified VARCHAR(50) DEFAULT NULL
);

DELIMITER $$
CREATE TRIGGER before_product_update 
    BEFORE UPDATE ON product
    FOR EACH ROW 
BEGIN
	declare s varchar(255);
    if (OLD.price > NEW.price) then
			SET s = 'Price Discount';
		else
			SET s = 'Price Increased';
		end if;
	if (OLD.price != NEW.price) then
		INSERT INTO product_tracking
		SET productid = OLD.productid,
		name = OLD.name,
		old_price = OLD.price,
        new_price = NEW.price,
        modified = s;
	end if;
END$$
DELIMITER ;

#### For testing
		insert into product (productid, name , price , description, categoryid) values (1009,'test' , 123, '123123123123', 3);

        update product set price = 200 where productid=1009;
        update product set price = 20 where productid=1009;
        update product set price = 200 where productid=1009;
        update product set price = 20 where productid=1009;
        update product set price = 2 where productid=1009;
        
        select * from product_tracking; 
#### Testing

#### Dropping
		drop table product_tracking;
		delete from product where productid=1009;
        
		drop trigger before_product_update;
        drop trigger before_delete_product;
        drop trigger before_delete_category;
####
        
        delimiter $$
        create trigger before_product_delete
        before delete on product
        for each row
        begin
			delete from reward where productid = OLD.productid;
            insert into product_tracking 
            set modified = 'Product deleted', productid= OLD.productid, name = OLD.name;
        end$$ 
        delimiter ;
        
        
        delimiter $$
        create trigger before_category_delete
        before delete on category
        for each row
        begin
			delete from product where categoryid = OLD.categoryid;
		end$$
		delimiter ;
        
        insert into category (categoryid,name) values (6,'test category');
        insert into product (name, price, categoryid) values ('asd',123,6);
        
        
        ###################################

############################################################



############################################################
CREATE TABLE employee_changes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    employeeid int not null,
    old_salary int,
    new_salary int,
    old_positionid int,
    new_positionid int,
    old_branchid int,
    new_branchid int,
    old_branch_name varchar(100),
    new_branch_name varchar(100),
    old_position_name varchar(50),
    new_position_name varchar(50),
    modified VARCHAR(255) DEFAULT NULL
);


DELIMITER $$
CREATE TRIGGER before_employee_update 
    BEFORE UPDATE ON employee
    FOR EACH ROW 
BEGIN
	declare s varchar(255);
    SET s = '';
    if (OLD.salary < NEW.salary) then
		SET s = concat(s,'Salary Raise ');
	elseif (Old.salary > New.salary) then
		SET s = concat(s, 'Salary Decreased ');
	end if;
    
    if (OLD.positionid != NEW.positionid) then
		SET s = concat(s,'Position Changed ');
	end if;
    
    if (OLD.branchid != NEW.branchid) then
		SET s = concat(s,'Branch Transfer');
	end if;
    
        
	if (OLD.salary != NEW.salary or OLD.branchid) then
		INSERT INTO employee_changes
		SET employeeid = OLD.employeeid,
		old_salary = OLD.salary,
        new_salary = NEW.salary,
        old_branchid = OLD.branchid,
        new_branchid = NEW.branchid,
        old_positionid = OLD.positionid,
        new_positionid = NEW.positionid,
        new_position_name = (select name from position where positionid=NEW.positionid),
        old_position_name = (select name from position where positionid=OLD.positionid),
        new_branch_name = (select concat(city,', ',country) from branch where branchid=NEW.branchid),
        old_branch_name = (select concat(city,', ',country) from branch where branchid=OLD.branchid),
        modified = s;
	end if;
    
END$$
DELIMITER ;

#### For Testing
		update employee set salary = 200 where employeeid=1006;
		update employee set salary = 300, branchid=1 where employeeid=1006;
		update employee set salary = 200, positionid=2 where employeeid=1006;
		update employee set salary = 200, branchid=2, positionid=4 where employeeid=1006;

		select * from employee_changes;
        
        select * from branch_transfers;
        select * from position_changes;
        select * from salary_changes;
####

#### Dropping
		drop view branch_transfers;
        drop view position_changes;
        drop view salary_changes;
		drop table employee_changes;
		drop trigger before_employee_update;

#### Custom View for better experience
		
        ####Branch Transfer View
		create view branch_transfers as
			select id, name, old_branch_name `Old Branch`, new_branch_name `New Branch` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_branch_name != new_branch_name;
            
		####Position Change View
        create view position_changes as
			select id, name, old_position_name `Old Position`, new_position_name `New Position` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_position_name != new_position_name;
            
		####Salary Change View
        create view salary_changes as
			select id, name, old_salary `Old Salary`, new_salary `New Salary` 
            from employee_changes ec join employee e 
            where ec.employeeid = e.employeeid and old_salary != new_salary;


