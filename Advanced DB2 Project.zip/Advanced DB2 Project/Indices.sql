CREATE INDEX `categoryid_idx` ON `SuperMarket`.`Product` (`categoryid` ASC) VISIBLE;

CREATE INDEX `branchid_idx` ON `SuperMarket`.`Employee` (`branchid` ASC) VISIBLE;

CREATE INDEX `employeeid_idx` ON `SuperMarket`.`Order` (`employeeid` ASC) VISIBLE;
CREATE INDEX `customerid_idx` ON `SuperMarket`.`Order` (`customerid` ASC) VISIBLE;

CREATE INDEX `orderid_idx` ON `SuperMarket`.`OrderDetails` (`orderid` ASC) VISIBLE;
CREATE INDEX `productid_idx` ON `SuperMarket`.`OrderDetails` (`productid` ASC) VISIBLE;

CREATE INDEX `productid_idx` ON `SuperMarket`.`Stock` (`productid` ASC) VISIBLE;

#CREATE INDEX `productid_idx` ON `SuperMarket`.`Supplier` (`productid` ASC) VISIBLE;

CREATE INDEX `branchid_idx` ON `SuperMarket`.`Manager` (`branchid` ASC) VISIBLE;

CREATE INDEX `supplierid_idx` ON `SuperMarket`.`SupplyDetails` (`supplierid` ASC) VISIBLE;
CREATE INDEX `productid_idx` ON `SuperMarket`.`SupplyDetails` (`productid` ASC) VISIBLE;

CREATE INDEX `productid_idx` ON `SuperMarket`.`Reward` (`productid` ASC) VISIBLE;