#Views

CREATE VIEW EmployeeView AS
    select employeeid, e.name name, phone, birthday, salary, employment_date,country, city, p.name positionname, b.branchid branchid, p.positionid positionid from Employee e join Branch b join Position p
where e.positionid=p.positionid and e.branchid = b.branchid;


Create View ProductView as
select p.productid, p.name, price, c.name category_name, description, c.categoryid from product p join category c where p.categoryid = c.categoryid;

create View RewardView as 
select p.productid, name, points, price from Reward r join Product p where r.productid = p.productid;
